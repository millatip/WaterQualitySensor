package com.uin.waterqualitysensor

data class SensorValue (var suhu: String? = "",
                        var ph: String? = "")
